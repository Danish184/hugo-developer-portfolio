---
title: "About"
date: 2019-05-12T12:14:34+06:00
description: "This is meta description."
author : "Sam Robbins"
authorImage : "images/about/profile.jpg"
---

Hi! I'm Sam, a second year Computer Science student from Durham University. 
I like doing personal projects, which you will find in the portfolio page of this website. 
My specialties can be found on the homepage, of which most are web development or cyber security.

I am currently available for part time remote work, but will be looking for full time employment from summer 2021.
